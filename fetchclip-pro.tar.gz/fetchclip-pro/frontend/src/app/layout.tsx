import type { Metadata } from 'next';
import { Inter, JetBrains_Mono } from 'next/font/google';
import { ThemeProvider } from 'next-themes';
import { Toaster } from 'sonner';
import './globals.css';

const inter = Inter({
  subsets: ['latin'],
  variable: '--font-sans',
  display: 'swap',
});

const jetbrainsMono = JetBrains_Mono({
  subsets: ['latin'],
  variable: '--font-mono',
  display: 'swap',
});

const SITE_URL = process.env.NEXT_PUBLIC_SITE_URL || 'https://fetchclip.pro';

export const metadata: Metadata = {
  metadataBase: new URL(SITE_URL),
  title: {
    default: 'FetchClip Pro — Free Video Downloader for YouTube, TikTok, Instagram & More',
    template: '%s | FetchClip Pro',
  },
  description: 'Download videos from YouTube, TikTok, Instagram, Facebook, Twitter/X and Pinterest in HD. Free, no signup required. Fast and easy.',
  keywords: ['video downloader', 'youtube downloader', 'tiktok downloader', 'instagram downloader', 'free video download', 'HD video download'],
  authors: [{ name: 'FetchClip Pro' }],
  creator: 'FetchClip Pro',
  openGraph: {
    type: 'website',
    locale: 'en_US',
    url: SITE_URL,
    siteName: 'FetchClip Pro',
    title: 'FetchClip Pro — Free Video Downloader',
    description: 'Download videos from YouTube, TikTok, Instagram & more. Free, no signup.',
    images: [{ url: '/og-image.png', width: 1200, height: 630, alt: 'FetchClip Pro' }],
  },
  twitter: {
    card: 'summary_large_image',
    title: 'FetchClip Pro — Free Video Downloader',
    description: 'Download videos from YouTube, TikTok, Instagram & more. Free, no signup.',
    images: ['/og-image.png'],
  },
  robots: { index: true, follow: true, googleBot: { index: true, follow: true } },
  alternates: { canonical: SITE_URL },
};

export default function RootLayout({ children }: { children: React.ReactNode }) {
  return (
    <html lang="en" suppressHydrationWarning className={`${inter.variable} ${jetbrainsMono.variable}`}>
      <head>
        <link rel="icon" href="/favicon.ico" sizes="any" />
        <link rel="apple-touch-icon" href="/apple-touch-icon.png" />
        <script
          type="application/ld+json"
          dangerouslySetInnerHTML={{
            __html: JSON.stringify({
              '@context': 'https://schema.org',
              '@type': 'WebApplication',
              name: 'FetchClip Pro',
              url: SITE_URL,
              description: 'Free video downloader for YouTube, TikTok, Instagram and more.',
              applicationCategory: 'UtilitiesApplication',
              operatingSystem: 'Any',
              offers: { '@type': 'Offer', price: '0', priceCurrency: 'USD' },
            }),
          }}
        />
      </head>
      <body className="font-sans bg-white dark:bg-gray-950 text-gray-900 dark:text-gray-100 antialiased">
        <ThemeProvider attribute="class" defaultTheme="system" enableSystem>
          {children}
          <Toaster richColors position="top-center" />
        </ThemeProvider>
      </body>
    </html>
  );
}
